<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Paket extends REST_Controller{
    
    public function __construct(){
        parent::__construct();
        $this->load->model('Mod_paket','paket');
    }
    public function index_get(){
        $id = $this->get('id');
        if ($id == null ) {
            $paket= $this->paket->getpaket();
        
        }else {
            $paket = $this->paket->getpaket($id);   
        }
        if ($paket) {
            $this->response([
                'status ' => true,
                'data' => $paket
            ],REST_Controller::HTTP_OK);
        }else {
            $this->response([
                'status' => false,
                'message' => 'paket tidak ditemukan'
            ],REST_Controller::HTTP_NOT_FOUND);
        }
    }
    
}