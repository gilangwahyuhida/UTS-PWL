# Sistem Informasi Laundry
Sistem informasi laundry ini merupakan project pribadi untuk pembelajaran saya dalam menggunakan framework codeigniter, fitur yang ada didalamnya masih sederhana.
## Fitur
Fitur di sistem ini yakni :
> - Sistem login
> - Managemen data user
> - Managemen data pelanggan
> - Managemen data paket
> - Managemen data transaksi
## Software 
> - Linux Mint 19.2 tina
> - Visual Studio Code 1.39.2
> - Google Chrome
> - Xampp
## System
> - Php 7.2.24
> - Codeigniter 3.1.10
### Username dan password
> - Username : sandy
> - Password : 1234
